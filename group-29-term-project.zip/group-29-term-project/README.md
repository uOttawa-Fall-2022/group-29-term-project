Term project of group 29 for SEG2105.
